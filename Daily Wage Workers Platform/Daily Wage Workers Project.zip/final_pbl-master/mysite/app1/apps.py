from django.apps import AppConfig


class App1Config(AppConfig):
    """Name Of Application"""
    name = "app1"
